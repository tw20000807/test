int ask(int i);
int guess(int l, int r);
