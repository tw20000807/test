#include<vector>

int find_coin(std::vector<int> b) {
    if (b[0] == 0) {
        return 0;
    }
    return 7;
}
